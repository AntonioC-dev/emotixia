const canvas = document.getElementById('sky');
const context = canvas.getContext('2d');
const starColors = ['#FFD63A', '#5B8DEF', '#F0524A', '#A78BFA', '#8BCB3C', '#FF9142', '#FF8FB8', '#3FC9BE'];
let width;
let height;
let stars = [];
let colorIndex = 0;
const colorTransitionDuration = 4000;
let colorTransitionStart = 0;
let starColorFrom = hexToRgb(starColors[0]);
let starColorTo = starColorFrom;
let pointerX = innerWidth / 2;
let pointerY = innerHeight / 2;

function hexToRgb(hex) {
    return {
        r: parseInt(hex.slice(1, 3), 16),
        g: parseInt(hex.slice(3, 5), 16),
        b: parseInt(hex.slice(5, 7), 16)
    };
}

function getStarColor(now) {
    const progress = Math.min(1, (now - colorTransitionStart) / colorTransitionDuration);
    const easedProgress = progress * progress * (3 - 2 * progress);
    const red = Math.round(starColorFrom.r + (starColorTo.r - starColorFrom.r) * easedProgress);
    const green = Math.round(starColorFrom.g + (starColorTo.g - starColorFrom.g) * easedProgress);
    const blue = Math.round(starColorFrom.b + (starColorTo.b - starColorFrom.b) * easedProgress);
    return `rgb(${red}, ${green}, ${blue})`;
}

function resizeSky() {
    width = canvas.width = innerWidth;
    height = canvas.height = innerHeight;
    stars = Array.from({ length: Math.floor(width * height / 3800) }, () => ({
        x: Math.random() * width,
        y: Math.random() * height,
        radius: Math.random() * 1.4 + .3,
        opacity: Math.random(),
        speed: (Math.random() * .008 + .002) * (Math.random() < .5 ? -1 : 1),
        parallax: Math.random() * .035
    }));
}

addEventListener('resize', resizeSky);
addEventListener('pointermove', event => {
    pointerX = event.clientX;
    pointerY = event.clientY;
});

setInterval(() => {
    starColorFrom = hexToRgb(getStarColor(performance.now()));
    colorIndex = (colorIndex + 1) % starColors.length;
    starColorTo = hexToRgb(starColors[colorIndex]);
    colorTransitionStart = performance.now();
    document.documentElement.style.setProperty('--sky-color', starColors[colorIndex]);
}, 4000);

document.documentElement.style.setProperty('--sky-color', starColors[colorIndex]);

function animateSky() {
    const now = performance.now();
    context.clearRect(0, 0, width, height);
    const offsetX = pointerX - width / 2;
    const offsetY = pointerY - height / 2;

    stars.forEach(star => {
        star.opacity += star.speed;
        if (star.opacity > 1 || star.opacity < .1) star.speed = -star.speed;

        context.globalAlpha = Math.max(0, Math.min(1, star.opacity));
        context.fillStyle = getStarColor(now);
        context.beginPath();
        context.arc(
            star.x - offsetX * star.parallax,
            star.y - offsetY * star.parallax,
            star.radius,
            0,
            Math.PI * 2
        );
        context.fill();
    });

    context.globalAlpha = 1;
    requestAnimationFrame(animateSky);
}

resizeSky();
animateSky();
