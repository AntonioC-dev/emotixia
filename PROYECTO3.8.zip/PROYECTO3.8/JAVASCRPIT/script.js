const INK = '#241a3a',
    CR = '#FFF8EC';

const E = [
    { n: 'Alegría', c: '#FFD63A', rx: 80, ry: 82, b: [70, 68], m: 'M62 126 Q100 172 138 126 Z', f: 1, d: 'Me encargo de que lo bueno brille y se quede en tus recuerdos.', x: 'Anota tres cosas que hoy te hicieron sonreír.' },
    { n: 'Tristeza', c: '#5B8DEF', rx: 72, ry: 88, b: [80, 66], m: 'M70 150 Q100 124 130 150', d: 'Me quedo contigo cuando algo duele. También sé cuidar.', x: 'Dale un minuto a lo que sientes y pide un abrazo si lo necesitas.' },
    { n: 'Furia', c: '#F0524A', rx: 86, ry: 76, b: [62, 82], m: 'M64 146 L136 146', d: 'Aparezco cuando algo cruza tus límites. ¡Y lo hago con ganas!', x: 'Inhala 4 segundos, exhala 6, y responde después.' },
    { n: 'Miedo', c: '#A78BFA', rx: 68, ry: 88, b: [68, 56], m: 'M84 142 Q100 168 116 142 Q100 132 84 142Z', f: 1, d: 'Soy tu radar. Prefiero que llegues sano y salvo.', x: 'Escribe lo peor, lo mejor y lo más probable que puede pasar.' },
    { n: 'Desagrado', c: '#8BCB3C', rx: 80, ry: 80, b: [74, 66], m: 'M70 146 Q85 132 100 146 T130 146', d: 'Cuido tus gustos y lo que no quieres en tu vida.', x: 'Pregúntate qué límite está protegiendo esta sensación.' },
    {
        n: 'Ansiedad',
        c: '#FF9142',
        rx: 78,
        ry: 80,
        b: [68, 58],
        m: 'M68 146 L81 136 L94 150 L107 136 L120 150 L133 140',
        x0: '<path d="M78 32 L70 10 M100 28 L100 6 M122 32 L130 10" stroke="' + CR + '" stroke-width="5" stroke-linecap="round"/>',
        d: 'Miro al futuro con mil escenarios a la vez. Perdón por el ruido.',
        x: 'Nombra 5 cosas que ves, 4 que tocas y 3 que oyes.'
    },
    {
        n: 'Vergüenza',
        c: '#FF8FB8',
        rx: 84,
        ry: 84,
        b: [72, 66],
        m: 'M76 144 Q88 134 100 144 Q112 134 124 144',
        x1: '<ellipse cx="46" cy="124" rx="15" ry="9" fill="#ff4f86" opacity=".55"/><ellipse cx="154" cy="124" rx="15" ry="9" fill="#ff4f86" opacity=".55"/>',
        d: 'Me pongo roja cuando siento que todos me miran.',
        x: 'Casi nadie nota tanto como imaginas. Respira y sigue.'
    },
    { n: 'Envidia', c: '#3FC9BE', rx: 70, ry: 72, b: [76, 70], m: 'M80 146 Q100 152 120 140', d: 'Miro lo que otros tienen para descubrir qué quieres tú.', x: 'Escribe qué admiras y qué paso pequeño te acercaría a eso.' },
    { n: 'Aburrimiento', c: '#7077E0', rx: 88, ry: 78, b: [86, 86], lid: 1, m: 'M80 148 L120 148', d: 'Me desconecto cuando nada parece importar. Suspiro.', x: 'Cambia algo mínimo hoy: otra ruta, otra canción, otra pregunta.' },
    { n: 'Nostalgia', c: '#D9B8E8', rx: 76, ry: 82, b: [74, 68], m: 'M74 138 Q100 158 126 138', d: 'Guardo los recuerdos que se sienten como casa.', x: 'Abre una foto vieja y cuéntale a alguien la historia.' }
];

// Dibuja la carita SVG de una emoción
function face(m) {
    const eye = x => `<g class="eye"><circle cx="${x}" cy="92" r="17" fill="#fff" stroke="${INK}" stroke-width="3"/><circle class="pp" cx="${x}" cy="92" r="7" fill="${INK}"/></g>`;
    const lid = m.lid ?
        `<rect x="54" y="74" width="36" height="18" fill="${m.c}"/><rect x="110" y="74" width="36" height="18" fill="${m.c}"/><path d="M54 92H90M110 92H146" stroke="${INK}" stroke-width="4" stroke-linecap="round"/>` :
        '';
    const [o, i] = m.b;
    const s = `stroke="${INK}" stroke-width="5" stroke-linecap="round" stroke-linejoin="round"`;
    return `<svg viewBox="0 0 200 200" class="w-full h-full overflow-visible" aria-hidden="true">${m.x0 || ''}<ellipse cx="100" cy="106" rx="${m.rx}" ry="${m.ry}" fill="${m.c}" stroke="${CR}" stroke-width="6"/>${m.x1 || ''}${eye(72)}${eye(128)}${lid}<path d="M52 ${o} L90 ${i}M148 ${o} L110 ${i}" fill="none" ${s}/><path d="${m.m}" fill="${m.f ? INK : 'none'}" ${s}/></svg>`;
}

const $ = id => document.getElementById(id);
const root = document.documentElement;
const orbit = $('orbit');
let cur = 0,
    ang = 0,
    hover = false,
    mx = innerWidth / 2,
    my = innerHeight / 2;

// Palabra EMOTIXIA: cada letra con el color de una emoción
const letters = [5, 1, 0, 6, 8, 2, 3, 9]; // orden de colores elegido a mano
const tilt = [-3, 2, -1, 3, -2, 1, -3, 2];
document.querySelector('.word').innerHTML = 'EMOTIXIA'.split('')
    .map((l, i) => `<span style="color:${E[letters[i]].c};transform:rotate(${tilt[i]}deg)">${l}</span>`)
    .join('');

// Emociones orbitando
const orbs = E.map((m, i) => {
    const b = document.createElement('button');
    b.className = 'orb';
    b.style.setProperty('--k', m.c);
    b.title = m.n;
    b.setAttribute('aria-label', m.n);
    b.setAttribute('aria-pressed', 'false');
    b.innerHTML = face(m);
    b.onclick = () => pick(i);
    orbit.appendChild(b);
    return b;
});

// Selecciona una emoción
function pick(i) {
    cur = (i + E.length) % E.length;
    const m = E[cur];
    root.style.setProperty('--c', m.c);
    orbs.forEach((b, j) => b.setAttribute('aria-pressed', j === cur));

    const c = $('core');
    c.innerHTML = face(m);
    c.classList.remove('boing');
    void c.offsetWidth; // reinicia la animación
    c.classList.add('boing');

    const bb = $('bubble');
    bb.style.opacity = 0;
    setTimeout(() => {
        $('bN').textContent = 'Soy ' + m.n;
        $('bD').textContent = m.d;
        $('bX').textContent = m.x;
        bb.style.opacity = 1;
    }, 150);
}

// Interacciones
$('core').onclick = () => pick(cur + 1);

addEventListener('keydown', e => {
    if (e.key === 'ArrowRight') pick(cur + 1);
    if (e.key === 'ArrowLeft') pick(cur - 1);
});

orbit.addEventListener('mouseenter', () => hover = true);
orbit.addEventListener('mouseleave', () => hover = false);

// Las pupilas siguen al puntero
addEventListener('pointermove', e => {
    mx = e.clientX;
    my = e.clientY;
    const r = $('core').getBoundingClientRect();
    const cx = r.left + r.width / 2,
        cy = r.top + r.height * .45;
    const dx = mx - cx,
        dy = my - cy;
    const d = Math.hypot(dx, dy) || 1;
    const k = Math.min(1, d / 200) * 7;
    $('core').querySelectorAll('.pp').forEach(p =>
        p.setAttribute('transform', `translate(${dx / d * k} ${dy / d * k})`)
    );
});

$('menu-btn').onclick = () => {
    const m = $('mobile-menu');
    m.classList.toggle('hidden');
    m.classList.toggle('flex');
};

// Cielo estrellado: algunas estrellas toman el color de la emoción activa
const cv = $('sky'),
    ctx = cv.getContext('2d');
let W, H, stars = [];

function size() {
    W = cv.width = innerWidth;
    H = cv.height = innerHeight;
    stars = Array.from({ length: Math.floor(W * H / 3800) }, () => ({
        x: Math.random() * W,
        y: Math.random() * H,
        r: Math.random() * 1.4 + .3,
        a: Math.random(),
        s: (Math.random() * .008 + .002) * (Math.random() < .5 ? -1 : 1),
        t: Math.random() < .22,
        z: Math.random() * .035
    }));
}
addEventListener('resize', size);
size();

// Bucle de animación
function loop() {
    ctx.clearRect(0, 0, W, H);
    const ox = mx - W / 2,
        oy = my - H / 2;

    stars.forEach(s => {
        s.a += s.s;
        if (s.a > 1 || s.a < .1) s.s = -s.s;
        ctx.globalAlpha = Math.max(0, Math.min(1, s.a));
        ctx.fillStyle = s.t ? E[cur].c : CR;
        ctx.beginPath();
        ctx.arc(s.x - ox * s.z, s.y - oy * s.z, s.r, 0, Math.PI * 2);
        ctx.fill();
    });
    ctx.globalAlpha = 1;

    if (!hover) ang += .0035;
    const R = orbit.clientWidth * .44;
    orbs.forEach((b, i) => {
        const a = ang + i * Math.PI * 2 / orbs.length;
        b.style.transform = `translate(-50%,-50%) translate(${Math.cos(a) * R}px,${Math.sin(a) * R}px)`;
    });

    requestAnimationFrame(loop);
}

pick(0);
loop();